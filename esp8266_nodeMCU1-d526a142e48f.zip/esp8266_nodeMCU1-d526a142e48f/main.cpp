#include "mbed.h"
#include "ESP8266.h"
#include "TCPSocketConnection.h"
#include <string>
using namespace std;

DigitalOut myled(LED1);
ESP8266 ark(PA_9,PA_10,D3,115200);
Serial pc(SERIAL_TX, SERIAL_RX);
TCPSocketConnection gm;

int main()
{
    pc.baud(115200);
    int i=0;
    while(1) {
        if(i==0) {
hardwareInit:
            pc.printf("intializing hardware,...\r\n");
            if(ark.init()) {
                pc.printf("hardware intialized!\r\n");
                i=1;
nustConnection:
                pc.printf("connecting to NUST,...\r\n");
                if(ark.connect("NUST","nust008tech")) {

                    pc.printf("NUST Connected!\r\n");
                    if(ark.is_connected()) {
                        pc.printf("connection confirmed!\r\n");
                        pc.printf("IP Adress: %s\r\n",ark.getIPAddress());
hostConnection:
                        pc.printf("connecting to Host,...\r\n");
                        if(gm.connect("207.58.139.247",80)==0) {
                            pc.printf("Host connected.\r\n");

                            char getRequest[] = "GET /testwifi/index.html HTTP/1.1\r\nHost: www.adafruit.com\r\nConnection: keep-alive\r\nAccept: */*\r\n\r\n";
sendGETRequest:
                            pc.printf("sending GET request,...\r\n");
                            if(gm.send_all(getRequest,strlen(getRequest))>0) {
                                pc.printf("GET requested!\r\n");

                                char getResponce[500]={};
                                pc.printf("reading responce of GET request!\r\n");
                                int resBytes = gm.receive_all(getResponce,500);
                                if(resBytes > 0) {
                                    pc.printf("Responce Received!\r\n");
                                    pc.printf("Responce:\r\n%s\r\n",getResponce);
                                } else if(resBytes==0) {
                                    pc.printf("Empty Responce!\r\n");
                                    goto sendGETRequest;
                                } else {
                                    pc.printf("Resopnce NOT Received!\r\n");
                                    goto sendGETRequest;
                                }

                            } else {
                                pc.printf("GET request failed!\r\n");
                                goto sendGETRequest;
                            }
                        } else {
                            pc.printf("Host Connection Failed\r\n");
                            goto hostConnection;
                        }
                    } else {
                        pc.printf("sonething went wrong with connection. not connected \r\n");
                        goto nustConnection;
                    }
                } else {
                    pc.printf("conenction fail!\r\n");
                    goto nustConnection;
                }
            } else {
                pc.printf("hardware not intialized!\r\n");
                goto hardwareInit;
            }
        }
        wait(1);
    }
}
